# Solely Social Marketing — Digital & Email Marketing Website

A responsive, modern one-page marketing website built with plain HTML, CSS, and JavaScript.

## Files
- `index.html` — website structure and content
- `styles.css` — responsive styling
- `script.js` — mobile menu, current year, and contact form mailto behavior

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `styles.css`, and `script.js`.
3. In the repository, go to **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/root`, then save.
5. GitHub will provide your live website URL.

## Customize
Search and replace:
- `Solely Social Marketing` with your business name.
- `hello@yourdomain.com` in `script.js` with your real email.
- The service descriptions and results with your actual offerings.
- Colors/fonts in `styles.css` if desired.
